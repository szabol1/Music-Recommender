import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class reducer extends Reducer<Text, DoubleWritable, Text, Text> {
    private Text result = new Text();

    public void reduce(Text key, Iterable<DoubleWritable> values, Context context)
            throws IOException, InterruptedException {
        // Calculate mean and standard deviation
        List<Double> valueList = new ArrayList<>();
        double sum = 0.0;
        int count = 0;

        // Iterate through values to calculate sum and count
        for (DoubleWritable value : values) {
            double doubleValue = value.get();
            sum += doubleValue;
            count++;
            valueList.add(doubleValue);
        }

        // Calculate mean
        double mean = sum / count;

        // Calculate sum of squared differences for standard deviation
        double sumSquaredDiffs = 0.0;
        for (Double doubleValue : valueList) {
            sumSquaredDiffs += Math.pow(doubleValue - mean, 2);
        }

        // Calculate standard deviation
        double stdDev = Math.sqrt(sumSquaredDiffs / count);

        // Output the mean and standard deviation as a comma-separated string
        result.set(mean + "," + stdDev);
        context.write(key, result);
    }
}

