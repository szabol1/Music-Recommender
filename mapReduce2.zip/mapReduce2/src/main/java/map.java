import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class map extends Mapper<LongWritable, Text, Text, DoubleWritable> {

    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        if (key.get() == 0) {
            return;
        }

        String[] lines = value.toString().split(",");

        String[] attributes = {"danceability","energy","keys","loudness","mode","speechiness","acousticness","instrumentalness","liveness","valence","tempo","time_signature"};

        for(int i = 0; i<lines.length;i++) {
            // Emit key-value pairs with the attribute as the key and the value as DoubleWritable
            String category = attributes[i];
            double attributeValue = Double.parseDouble(lines[i]);
            context.write(new Text(category), new DoubleWritable(attributeValue));

        }
    }
}