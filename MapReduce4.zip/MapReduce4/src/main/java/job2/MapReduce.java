package job2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

public class MapReduce {

    public static void main(String[] args) throws Exception {
        // Create a configuration object
        Configuration conf = new Configuration();

        // Create a new job and set the job name
        Job job = Job.getInstance(conf, "job3");

        // Set the class names for Mapper, Reducer, and the main class
        job.setJarByClass(MapReduce.class);
        job.setMapperClass(Map4.class);
        job.setReducerClass(Reducer4.class);

        // Set the output key and value classes
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);

        // Set the input and output paths
        Path inputPath = new Path("/modified_playlist2.csv");
        Path outputPath = new Path("/job3");
        // Modify the input and output paths accordingly


        // Set the input and output paths
        job.setInputFormatClass(org.apache.hadoop.mapreduce.lib.input.TextInputFormat.class);
        org.apache.hadoop.mapreduce.lib.input.FileInputFormat.addInputPath(job, inputPath);
        org.apache.hadoop.mapreduce.lib.output.FileOutputFormat.setOutputPath(job, outputPath);

        // Wait for the job to complete
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
