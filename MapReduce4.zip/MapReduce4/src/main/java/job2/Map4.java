package job2;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import java.io.IOException;
import java.util.ArrayList;

public class Map4 extends Mapper<LongWritable, Text, NullWritable, Text> {
    double[] means = {0.5162975285171114, 0.5068032994296587, 5.065114068441065, -10.519690589353598, 0.7961026615969582, 0.04681093155893531, 0.400593302932509, 0.10198921073193905, 0.18773255703422026, 0.5330288070342211, 120.108885456274, 3.875};
    double[] stdDevs = {0.14544036929445610, 0.2282241765243514, 3.5719172523605365, 4.273045103110821, 0.40289355144405153, 0.04681093155893531, 0.3076095556362564, 0.24441333942305757, 0.14980444045539404, 0.2605827943040613, 27.343397704706256, 0.4404267935267719};

    ArrayList<String> inRangeGenres = new ArrayList<String>();

    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        if (key.get() == 0) {
            return;
        }

        String[] columns = value.toString().split(",");
        int j = 0;
        for (int i = 1; i < columns.length; i++) {

                double columnValue = Double.parseDouble(columns[i]);

                // Binning logic based on mean and std_dev
                double lowerBound = means[j] - 1 * stdDevs[j];
                double upperBound = means[j] + 1 * stdDevs[j];

                if (columnValue >= lowerBound && columnValue <= upperBound) {
                    columns[i] = "InRange";
                } else {
                    columns[i] = "OutOfRange";
                }
                j++;
            }

        System.out.println(String.join(",", columns));
        context.write(NullWritable.get(), new Text(String.join(",", columns)));
        }

    }



