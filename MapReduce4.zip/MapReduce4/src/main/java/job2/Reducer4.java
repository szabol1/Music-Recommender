package job2;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class Reducer4 extends Reducer<NullWritable, Text,NullWritable, Text> {
    public void reducer2(NullWritable key, Iterable<Text> values, Context context)throws IOException, InterruptedException {

        for(Text value:values){
            context.write(NullWritable.get(), value);
        }
    }
}
